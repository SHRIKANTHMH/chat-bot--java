package ua.ivanzaitsev.bot.handlers;

import ua.ivanzaitsev.bot.models.domain.Command;

public interface Handler {

    Command getCommand();

}
