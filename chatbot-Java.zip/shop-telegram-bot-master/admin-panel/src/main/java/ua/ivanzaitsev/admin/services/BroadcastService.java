package ua.ivanzaitsev.admin.services;

public interface BroadcastService {

    void send(String message);

}
